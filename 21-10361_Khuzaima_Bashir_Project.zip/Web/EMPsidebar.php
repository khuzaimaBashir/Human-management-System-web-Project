<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">

	<link rel="stylesheet" href="sidebar.css">
	<script src="https://kit.fontawesome.com/b99e675b6e.js"></script>
</head>
<body>

<div class="wrapper">
    <div class="sidebar">
        <h2>HRM</h2>
        <ul>
            <li><a href="EMPHome.php"></i>Home</a></li>
            <li><a href="EmployeeManagement.php"></i>Employee Management</a></li>
            <li><a href="EmpTaskAssigned.php"></i>Task</a></li>
            <li><a href="assetcheck.php"></i>Check Assigned Asset </a></li>
            <li><a href="vacationcheck.php"></i>Holidays</a></li>
            <li><a href="TimeSheet.php"></i>Timesheet</a></li>
            <li><a href="EMPCheckReview.php"></i>Check Review</a></li>
            <li><a href="salarycheck.php"></i>Check Salary</a></li>
            <li><a href="Career.php"></i>Career</a></li>
            <li><a href="Logout.php"></i>LogOut</a></li>
        </ul> 
    </div>
 

</body>
</html>