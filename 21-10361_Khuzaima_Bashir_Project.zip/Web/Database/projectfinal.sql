-- phpMyAdmin SQL Dump
-- version 4.8.5
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Dec 18, 2019 at 04:01 PM
-- Server version: 5.7.26
-- PHP Version: 7.2.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectfinal`
--

-- --------------------------------------------------------

--
-- Table structure for table `adminlog`
--

DROP TABLE IF EXISTS `adminlog`;
CREATE TABLE IF NOT EXISTS `adminlog` (
  `id` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Username` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Pass` varchar(50) CHARACTER SET utf8 NOT NULL,
  `AdminName` varchar(99) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adminlog`
--

INSERT INTO `adminlog` (`id`, `Username`, `Pass`, `AdminName`, `reg_date`) VALUES
('AD101', 'Ali', 'admin', 'Ali Abbas', '2019-12-17 18:03:32'),
('AD102', 'Ahmed', 'admin', 'Ahmed Amin', '2019-12-17 18:03:32'),
('AD103', 'Aladin', 'admin', 'Aladin kamal', '2019-12-17 18:03:32'),
('AD104', 'Akmal', 'admin', 'Akmal Kamran', '2019-12-17 18:03:32'),
('Ad105', 'Admin', 'admin', 'Testing Admin', '2019-12-18 15:56:20');

-- --------------------------------------------------------

--
-- Table structure for table `applications`
--

DROP TABLE IF EXISTS `applications`;
CREATE TABLE IF NOT EXISTS `applications` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Vacancy` int(6) NOT NULL,
  `App_Status` varchar(999) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`),
  KEY `Vacancy` (`Vacancy`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `applications`
--

INSERT INTO `applications` (`id`, `EMPid`, `Vacancy`, `App_Status`, `reg_date`) VALUES
(1, 'EMP101', 1, 'Waiting', '2019-12-17 18:18:58'),
(2, 'EMP104', 3, 'Approve', '2019-12-17 18:18:58'),
(5, 'EMP105', 3, 'Waiting', '2019-12-18 12:22:57'),
(4, 'EMP103', 2, 'Waiting', '2019-12-17 18:18:58');

-- --------------------------------------------------------

--
-- Table structure for table `asset`
--

DROP TABLE IF EXISTS `asset`;
CREATE TABLE IF NOT EXISTS `asset` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `ASSET` varchar(99) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `asset`
--

INSERT INTO `asset` (`id`, `EMPid`, `ASSET`, `reg_date`) VALUES
(1, 'EMP101', 'I DONT KNOW WHAT IS THIS', '2019-12-17 18:18:14'),
(2, 'EMP104', 'Bike', '2019-12-18 15:17:39'),
(4, 'EMP103', 'I DONT KNOW WHAT IS THIS', '2019-12-17 18:18:14'),
(5, 'EMP101', 'I DONT KNOW WHAT IS THIS', '2019-12-17 18:18:31'),
(9, 'EMP105', 'Car', '2019-12-17 20:53:38'),
(8, 'EMP103', 'I DONT KNOW WHAT IS THIS', '2019-12-17 18:18:31');

-- --------------------------------------------------------

--
-- Table structure for table `claim`
--

DROP TABLE IF EXISTS `claim`;
CREATE TABLE IF NOT EXISTS `claim` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Query` varchar(999) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `claim`
--

INSERT INTO `claim` (`id`, `EMPid`, `Query`, `reg_date`) VALUES
(1, 'EMP103', 'Well Last month my Gasoline bill was 12200 dollars which is to be covered by company but company didnt cover it', '2019-12-17 18:19:23'),
(2, 'EMP101', 'My tour expenditure were supposed to be covered by comapany kindly add them to my next salary . P.S the expenditure was 2000 dollars', '2019-12-17 18:19:23');

-- --------------------------------------------------------

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
CREATE TABLE IF NOT EXISTS `company` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Company_info` varchar(999) CHARACTER SET utf8 DEFAULT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `company`
--

INSERT INTO `company` (`id`, `Company_info`, `reg_date`) VALUES
(1, 'This Company was established in 2019', '2019-12-17 18:19:48'),
(2, 'The Work done by this Company over last few year includes over thousand of projects', '2019-12-17 18:19:48');

-- --------------------------------------------------------

--
-- Table structure for table `emplog`
--

DROP TABLE IF EXISTS `emplog`;
CREATE TABLE IF NOT EXISTS `emplog` (
  `id` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Username` varchar(50) CHARACTER SET utf8 NOT NULL,
  `Pass` varchar(50) CHARACTER SET utf8 NOT NULL,
  `EMPNAME` varchar(99) CHARACTER SET utf8 NOT NULL,
  `EMP_DESIGNATION` varchar(99) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `emplog`
--

INSERT INTO `emplog` (`id`, `Username`, `Pass`, `EMPNAME`, `EMP_DESIGNATION`, `reg_date`) VALUES
('EMP101', 'MKB', 'admin', 'KHUZAIMA', 'GM', '2019-12-17 18:00:55'),
('EMP102', 'Employee', 'admin', 'Muhammad Khuzaima Bashir', 'CEO', '2019-12-18 14:38:05'),
('EMP103', 'TA', 'admin', 'Zaim', 'Boss', '2019-12-18 14:41:19'),
('EMP104', 'TAY', 'admin', 'TAYYAB', 'RGM', '2019-12-17 18:00:55'),
('EMP105', 'MIK', 'admin', 'Muhammad Imran Khan', 'GM', '2019-12-18 11:33:03');

-- --------------------------------------------------------

--
-- Table structure for table `employeereviews`
--

DROP TABLE IF EXISTS `employeereviews`;
CREATE TABLE IF NOT EXISTS `employeereviews` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPreview` varchar(999) CHARACTER SET utf8 NOT NULL,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employeereviews`
--

INSERT INTO `employeereviews` (`id`, `EMPreview`, `EMPid`, `reg_date`) VALUES
(1, 'JOB IS DIFFICULT', 'EMP101', '2019-12-17 18:15:05'),
(3, 'JOB IS NOT RELAXING', 'EMP104', '2019-12-17 18:15:05'),
(4, 'JOB IS NOT DIFFICULT', 'EMP103', '2019-12-17 18:15:05'),
(5, 'JOB IS DIFFICULT', 'EMP101', '2019-12-17 18:17:50'),
(7, 'JOB IS NOT RELAXING', 'EMP104', '2019-12-17 18:17:50'),
(8, 'JOB IS NOT DIFFICULT', 'EMP103', '2019-12-17 18:17:50'),
(9, 'JOB IS DIFFICULT', 'EMP101', '2019-12-17 18:18:06'),
(13, 'Well the Project of Web App is lengthy', 'EMP104', '2019-12-18 07:30:56'),
(11, 'JOB IS NOT RELAXING', 'EMP104', '2019-12-17 18:18:06'),
(12, 'JOB IS NOT DIFFICULT', 'EMP103', '2019-12-17 18:18:06'),
(14, 'The Timing should be flexible .', 'EMP105', '2019-12-18 11:16:53');

-- --------------------------------------------------------

--
-- Table structure for table `jobvacancy`
--

DROP TABLE IF EXISTS `jobvacancy`;
CREATE TABLE IF NOT EXISTS `jobvacancy` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `JobName` varchar(50) NOT NULL,
  `JobDescription` varchar(999) NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `jobvacancy`
--

INSERT INTO `jobvacancy` (`id`, `JobName`, `JobDescription`, `reg_date`) VALUES
(1, 'Janitor', 'Cleaning of offices', '2019-12-17 18:03:48'),
(2, 'Sales Manger', 'Driving and Maintainence of cars', '2019-12-18 13:54:14'),
(3, 'CFO', 'Financial assitance', '2019-12-17 18:03:48'),
(4, 'Accounts', 'Maintainence of accounts', '2019-12-17 18:03:48'),
(29, 'Sales Manger', 'Manager will have to follow his superior and try to achieve Sales Targer', '2019-12-17 19:10:42');

-- --------------------------------------------------------

--
-- Table structure for table `payroll`
--

DROP TABLE IF EXISTS `payroll`;
CREATE TABLE IF NOT EXISTS `payroll` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Salary` varchar(999) CHARACTER SET utf8 NOT NULL,
  `Dues` varchar(999) CHARACTER SET utf8 DEFAULT NULL,
  `Bonus` varchar(999) CHARACTER SET utf8 DEFAULT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payroll`
--

INSERT INTO `payroll` (`id`, `EMPid`, `Salary`, `Dues`, `Bonus`, `reg_date`) VALUES
(1, 'EMP103', '20', NULL, NULL, '2019-12-17 18:19:11'),
(2, 'EMP104', '10', NULL, NULL, '2019-12-17 18:19:11'),
(4, 'EMP101', '8000', '1200', '1000', '2019-12-18 15:45:44'),
(6, 'EMP105', '5000', NULL, NULL, '2019-12-17 22:14:10');

-- --------------------------------------------------------

--
-- Table structure for table `task`
--

DROP TABLE IF EXISTS `task`;
CREATE TABLE IF NOT EXISTS `task` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Task` varchar(999) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `task`
--

INSERT INTO `task` (`id`, `EMPid`, `Task`, `reg_date`) VALUES
(1, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:38'),
(2, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:38'),
(3, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:38'),
(4, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:38'),
(6, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:51'),
(7, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:51'),
(8, 'EMP101', 'ACHIEVE THE SALE TARGET', '2019-12-17 18:18:51'),
(9, 'EMP105', 'Tour onwards from Islamabad to Peshawar', '2019-12-18 15:02:50'),
(12, 'EMP103', 'ACHIEVE THE SALE TARGET', '2019-12-18 07:37:47'),
(13, 'EMP104', '', '2019-12-18 15:15:17');

-- --------------------------------------------------------

--
-- Table structure for table `timesheet`
--

DROP TABLE IF EXISTS `timesheet`;
CREATE TABLE IF NOT EXISTS `timesheet` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `EMPid` varchar(10) CHARACTER SET utf8 NOT NULL,
  `Logged` varchar(99) CHARACTER SET utf8 NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `EMPid` (`EMPid`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `timesheet`
--

INSERT INTO `timesheet` (`id`, `EMPid`, `Logged`, `reg_date`) VALUES
(1, 'EMP101', 'LOG IN', '2019-12-17 18:17:17'),
(2, 'EMP103', 'LOG IN', '2019-12-17 18:17:17'),
(3, 'EMP104', 'LOG IN', '2019-12-17 18:17:17'),
(4, 'EMP101', 'LOG OUT', '2019-12-17 18:17:17'),
(5, 'EMP103', 'LOG out', '2019-12-17 18:17:17'),
(6, 'EMP104', 'LOG out', '2019-12-17 18:17:17'),
(7, 'EMP101', 'LOG IN', '2019-12-17 18:17:40'),
(8, 'EMP103', 'LOG IN', '2019-12-17 18:17:40'),
(9, 'EMP104', 'LOG IN', '2019-12-17 18:17:40'),
(10, 'EMP101', 'LOG OUT', '2019-12-17 18:17:40'),
(11, 'EMP103', 'LOG out', '2019-12-17 18:17:40'),
(12, 'EMP104', 'LOG out', '2019-12-17 18:17:40'),
(13, 'EMP105', 'LOG IN', '2019-12-18 12:55:27'),
(14, 'AD101', 'LOG OUT', '2019-12-18 13:02:19'),
(15, 'EMP105', 'LOG IN', '2019-12-18 13:02:37'),
(16, 'EMP105', 'LOG OUT', '2019-12-18 13:06:12'),
(17, 'EMP105', 'LOG IN', '2019-12-18 15:46:02'),
(18, 'EMP105', 'LOG OUT', '2019-12-18 15:46:36'),
(19, 'EMP102', 'LOG IN', '2019-12-18 15:58:16'),
(20, 'EMP102', 'LOG OUT', '2019-12-18 15:58:30');

-- --------------------------------------------------------

--
-- Table structure for table `vacations`
--

DROP TABLE IF EXISTS `vacations`;
CREATE TABLE IF NOT EXISTS `vacations` (
  `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT,
  `Vacation_Date` date NOT NULL,
  `reg_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vacations`
--

INSERT INTO `vacations` (`id`, `Vacation_Date`, `reg_date`) VALUES
(1, '2000-12-02', '2019-12-17 18:19:36'),
(2, '2012-02-24', '2019-12-17 18:19:36'),
(3, '2001-02-24', '2019-12-17 18:19:36'),
(4, '2009-10-30', '2019-12-17 18:19:36'),
(5, '2014-02-22', '2019-12-17 21:17:11');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
