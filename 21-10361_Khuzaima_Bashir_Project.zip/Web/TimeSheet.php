<?php 
session_start();
include ("database.php");
include ("EMPsidebar.php");
$id= $_SESSION['rainbow_uid'];
$query= "select * from TimeSheet WHERE EMPid =  '$id'";  //After where empid add $_variable for server side use
$result=mysqli_query($conn,$query);
?>

<!DOCTYPE html>
<html>
    <title>
        Fetch Data From Database
    </title>
<body>
    <link rel="stylesheet" href="btn.css">
<div class = "btn">
<table  class="displayTable">
    <tr>
    <th colspan="3"><h2>Employees TimeSheet Log </h2></th>
    </tr>
<tr>
    <th>id </th>
    <th> EMP ID </th>
    <th> LOG IN / LOG OUT </th>
    <th> LOGGED Time & Date </th>
</tr>

<tr>
<?php
while($rows=mysqli_fetch_assoc($result)){
?>
<td><?php echo $rows["id"]; ?></td>
<td><?php echo $rows["EMPid"]; ?></td>
<td><?php echo $rows["Logged"]; ?></td>
<td><?php echo $rows["reg_date"]; ?></td>

</tr>
<?php
}
?>
</table>
</div>
</body>
</html>