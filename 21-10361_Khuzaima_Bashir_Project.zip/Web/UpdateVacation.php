<?php
include('database.php');
$id = $_POST["id"];
$Description=$_POST['date'];

$sql = "UPDATE Vacations SET Vacation_date='$Description' WHERE id= '$id'";
mysqli_query($conn, $sql);
?>